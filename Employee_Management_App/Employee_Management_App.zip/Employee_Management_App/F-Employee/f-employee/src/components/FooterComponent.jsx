import React from 'react'

const FooterComponent =()=>{
    return(
        <div>
            <footer className='footer bg-secondary'>
                <span>All right reserved by ImpliCode 2025</span>
            </footer>
        </div>
    )
}

export default FooterComponent