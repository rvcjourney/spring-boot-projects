package com.example.B_Employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BEmployeeApplication {
	public static void main(String[] args) {
		SpringApplication.run(BEmployeeApplication.class, args);
	}
}
