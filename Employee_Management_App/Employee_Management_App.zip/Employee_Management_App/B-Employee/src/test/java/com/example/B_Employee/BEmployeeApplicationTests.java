package com.example.B_Employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
